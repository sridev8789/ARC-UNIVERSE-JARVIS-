This project expects a Gradle wrapper for the GitHub Actions workflow.
If your Android IDE generates a wrapper, commit gradlew, gradlew.bat, and gradle/wrapper/*.
Alternatively, use an Android IDE that can sync the Gradle project directly.
