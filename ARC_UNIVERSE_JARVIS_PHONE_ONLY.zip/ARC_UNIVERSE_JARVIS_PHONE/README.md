# ARC UNIVERSE JARVIS — Phone-Only Build

Package: `com.arcuniverse.jarvis`

## What this project does
- Voice input using Android Speech Recognition
- Text-to-Speech responses
- Persistent local memory
- Remember / forget / show memory / clear memory commands
- Tamil and English basic interaction
- No server required for the memory system

## Build directly from a phone
This project is prepared for Android Gradle builds.

### Option A: Android IDE
Open the extracted project in a compatible Android IDE, sync Gradle, then build the APK.

### Option B: GitHub Actions
Upload this project to a GitHub repository. The workflow in `.github/workflows/build-apk.yml` automatically builds a debug APK. After the workflow finishes, download the APK artifact from the Actions run.

## Important
The APK is installed on the phone. The memory is stored locally inside the app's private storage. A USB/pen-drive portable-memory system is not included in this minimal phone-only build.
