package com.arcuniverse.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var statusText: TextView
    private lateinit var outputText: TextView
    private lateinit var inputText: EditText
    private lateinit var listenButton: Button
    private lateinit var clearButton: Button
    private lateinit var tts: TextToSpeech

    private val memories = mutableListOf<String>()
    private val prefs by lazy { getSharedPreferences("jarvis_memory", MODE_PRIVATE) }
    private val requestAudio = 1001
    private val requestSpeech = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        outputText = findViewById(R.id.outputText)
        inputText = findViewById(R.id.inputText)
        listenButton = findViewById(R.id.listenButton)
        clearButton = findViewById(R.id.clearButton)

        tts = TextToSpeech(this, this)
        loadMemory()

        listenButton.setOnClickListener { startListening() }
        clearButton.setOnClickListener {
            memories.clear()
            saveMemory()
            reply("Memory cleared.")
        }

        inputText.setOnEditorActionListener { _, _, _ ->
            processCommand(inputText.text.toString())
            true
        }

        statusText.text = "ARC UNIVERSE JARVIS • Memory: ${memories.size}"
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                requestAudio
            )
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        try {
            startActivityForResult(intent, requestSpeech)
            statusText.text = "Listening..."
        } catch (e: Exception) {
            reply("Speech recognition is not available on this phone.")
        }
    }

    @Deprecated("Android callback API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?: return

            inputText.setText(text)
            processCommand(text)
        }
    }

    private fun processCommand(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return

        val lower = text.lowercase(Locale.getDefault())

        when {
            lower == "hello" || lower.contains("hello jarvis") ||
                    text.contains("வணக்கம்") -> {
                reply(if (text.any { it in 'அ'..'ஹ' }) "வணக்கம்! நான் JARVIS." else "Hello! I am JARVIS.")
            }

            lower.contains("show memory") ||
                    lower.contains("what do you remember") ||
                    text.contains("மெமரி") -> {
                if (memories.isEmpty()) reply("I don't have any saved memories yet.")
                else reply("I remember: " + memories.joinToString(" • "))
            }

            lower.contains("memory count") -> {
                reply("I have ${memories.size} saved memories.")
            }

            lower.startsWith("remember ") -> {
                val memory = text.substringAfter("remember ").trim()
                learn(memory)
                reply("I will remember that.")
            }

            lower.startsWith("forget ") -> {
                val target = text.substringAfter("forget ").trim()
                val removed = memories.removeAll { it.contains(target, ignoreCase = true) }
                saveMemory()
                reply(if (removed) "Removed matching memory." else "I couldn't find that memory.")
            }

            lower == "clear memory" || lower == "clear all memory" -> {
                memories.clear()
                saveMemory()
                reply("All memory has been cleared.")
            }

            lower.contains("time") -> {
                val time = java.text.SimpleDateFormat(
                    "hh:mm a",
                    Locale.getDefault()
                ).format(java.util.Date())
                reply("The time is $time.")
            }

            lower.contains("date") -> {
                val date = java.text.SimpleDateFormat(
                    "dd MMMM yyyy",
                    Locale.getDefault()
                ).format(java.util.Date())
                reply("Today is $date.")
            }

            else -> {
                // Automatic memory: save meaningful personal/project statements.
                if (shouldRemember(text)) {
                    learn(text)
                }
                reply("I heard you: $text")
            }
        }

        inputText.text.clear()
    }

    private fun shouldRemember(text: String): Boolean {
        val lower = text.lowercase(Locale.getDefault())
        val indicators = listOf(
            "my name", "i am", "i'm", "my project", "my goal",
            "remember", "i like", "i want", "my plan", "arc universe",
            "என் பெயர்", "எனக்கு", "என் project", "என் இலக்கு"
        )
        return indicators.any { lower.contains(it) } && text.length >= 8
    }

    private fun learn(text: String) {
        if (text.isBlank()) return
        if (!memories.any { it.equals(text, ignoreCase = true) }) {
            memories.add(text)
            saveMemory()
            statusText.text = "ARC UNIVERSE JARVIS • Memory: ${memories.size}"
        }
    }

    private fun saveMemory() {
        val array = JSONArray()
        memories.forEach { array.put(it) }
        prefs.edit().putString("items", array.toString()).apply()
    }

    private fun loadMemory() {
        memories.clear()
        val raw = prefs.getString("items", null) ?: return
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                memories.add(array.getString(i))
            }
        } catch (_: Exception) {
            memories.clear()
        }
    }

    private fun reply(message: String) {
        outputText.text = message
        speak(message)
    }

    private fun speak(message: String) {
        if (::tts.isInitialized) {
            tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_REPLY")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
